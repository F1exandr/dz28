from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:postgres@localhost:5433/test'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# Таблицы для базы данных
class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String, nullable=False)
    content = db.Column(db.Text, nullable=False)
    author = db.Column(db.String, nullable=False)  # добавлено поле author


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    post_id = db.Column(db.Integer, db.ForeignKey('post.id'), nullable=False)
    author = db.Column(db.String, nullable=False)  # добавлено поле author

    post = db.relationship('Post', backref=db.backref('comments', lazy=True))


with app.app_context():
    db.create_all()


@app.route('/')
def index():
    posts = Post.query.all()
    return render_template('index.html', posts=posts)


@app.route('/add_post', methods=['GET', 'POST'])
def add_post():
    if request.method == 'POST':
        title_form = request.form['title']
        content_form = request.form['content']
        author_form = request.form['author']
        new_post = Post(title=title_form, content=content_form, author=author_form)
        db.session.add(new_post)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_post.html')


@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def view_post(post_id):
    post = Post.query.get_or_404(post_id)
    if request.method == 'POST':
        comment_text = request.form['content']
        author_form = request.form['author']
        new_comment = Comment(content=comment_text, post_id=post_id, author=author_form)
        db.session.add(new_comment)
        db.session.commit()
        return redirect(url_for('view_post', post_id=post_id))
    return render_template('view_post.html', post=post)


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
